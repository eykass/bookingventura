@extends('layouts.app')

@section('content')


<h2> Thank You for your booking</h2>
<h2> Your booking will be procced with 24 hour</h2>

@endsection