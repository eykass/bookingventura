<?php $__env->startSection('content'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Payment</h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
</div>

<!-- Content Row -->

<div class="row">

    <!-- Manage Payment Table -->
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Manage Payment</h6>
            </div>
            <!-- Card Body -->
            <div class="card-body">

                <div class="row">

                    <div class="col">
                        <!-- <a href="<?php echo e(route('payment.create')); ?>" class="btn btn-primary btn-sm"> <i class="fas fa-fw fa-plus"></i> New payment
                        </a> -->
                    </div>

                     <div class="d-none d-sm-inline col-sm-auto">
                        <a href="<?php echo e(route('payment.index')); ?>" class="d-none d-sm-inline btn btn-primary btn-sm"><i class="fas fa-fw fa-eraser"></i>
                        </a>
                    </div>

                    <div class="col col-lg-3" >
                        <form action ="<?php echo e(route('payment.index')); ?>" method="get">
                            <div class="input-group input-group-sm">
                                <input type="search" name="search" class="form-control input-sm">
                                <span class="input-group-prepend">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-fw fa-search"></i></button>
                                </span>
                            </div>
                        </form>
                    </div>

                </div>
                    
                <br>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <tr>
                            <th style="text-align:center;">#</th>
                            <th>Booking No.</th>
                            <th>Customer Details</th>
                            <th>Mode</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Ref</th>
                            <th style="text-align:center;">Details</th>
                        </tr>

                        <?php ($i=1); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="text-align:center;"><?php echo e(($payments->currentPage() - 1) * $payments->links()->paginator->perPage() + $loop->iteration); ?></td>

                            <td><?php echo e($payment->booking()->booking_no); ?></td>
                            <td><?php echo e($payment->customer()->name); ?>  <br>
                                <?php echo e($payment->customer()->phone); ?>

                            </td>
                            <td><?php echo e($payment->mode); ?></td>
                            <td>RM<?php echo e(number_format($payment->amount,2,".",",")); ?></td>
                            <td>
                                <?php if($payment->status == 1): ?>
                                    Success
                                <?php elseif($payment->status == 2): ?>
                                    Unsuccessful
                                <?php elseif($payment->status == 3): ?>
                                    Unsuccessful
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($payment->ref); ?></td>

                            <td style="text-align:center;">
                                <form method="POST" action="<?php echo e(route('payment.destroy', $payment->id)); ?>">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <?php echo csrf_field(); ?>
                                    <div class="btn-group">
                                        <!-- <button class=" btn btn-sm btn-danger">
                                            <i class="icon-trash"> Trash</i>
                                        </button>
                                        -->
                                    </div>
                                </form>
                            
                                &nbsp;
                            
                                <?php if($payment->status == 1): ?>
                                    <a href="<?php echo e(route('payment.show', $payment->id)); ?>" onclick="window.open(this.href, '_blank', 'left=20,top=20,width=550,height=500,toolbar=1,resizable=0'); return false;" class=" btn btn-sm btn-info">
                                        <i class="fas fa-fw fa-file"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-center">No result found <strong>: <?php echo e(request()->query('search')); ?></strong></p>
                        <?php endif; ?>
                    </table>
                </div>
                <?php echo e($payments->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\booking\resources\views/payment_index.blade.php ENDPATH**/ ?>